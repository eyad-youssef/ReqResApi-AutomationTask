package resources;
//enum is special class in java which has collection of constants or  methods
public enum APIResources {


//10.230.86.35
	deletePostByIDAPI("https://reqres.in/api"),
	getUsersAPI("https://reqres.in/api/users"),
	addPostAPI("https://reqres.in/api/");
	private String resource;
	APIResources(String resource)
	{
		this.resource=resource;
	}
	
	public String getResource()
	{
		return resource;
	}
	

}
