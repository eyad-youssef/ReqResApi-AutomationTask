package resources;

import pojo.RegisterPojo;

public class TestDataBuild {

    public RegisterPojo create( ){
        RegisterPojo addUser =new RegisterPojo();
        addUser.setName("ali");
        addUser.setJob("doctor");




        return addUser;
    }
}
