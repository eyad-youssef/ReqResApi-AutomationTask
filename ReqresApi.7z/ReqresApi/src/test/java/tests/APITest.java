package tests;

import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.Assert;
import org.testng.annotations.Test;
import resources.TestDataBuild;
import resources.Utils;

import java.io.IOException;

import static io.restassured.RestAssured.given;

public class APITest extends Utils {

    RequestSpecification res;
    ResponseSpecification responsespec;
    Response response;
    TestDataBuild testData = new TestDataBuild();


    @Test(priority = 1)
    public void getUsers() throws IOException {
        responsespec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.HTML).build();
        res = given().spec(requestSpecification());


               response = res.when().get("?page=2")
                       .then().spec(responsespec).log().all().extract().response();
                       Assert.assertEquals(response.getStatusCode(), 200);



    }


    @Test (priority = 2)
    public void addUser() throws IOException {
        responsespec = new ResponseSpecBuilder().expectStatusCode(201).
                expectContentType(ContentType.JSON).build();
                res = given().spec(requestSpecification())
                .body(testData.create());

                 response = res.when().post("users")
                .then().spec(responsespec).extract().response();
                 Assert.assertEquals(response.getStatusCode(), 201);


    }


  @Test (priority = 3)
    public void deleteUser() throws IOException {
        responsespec = new ResponseSpecBuilder().expectStatusCode(204).expectContentType(ContentType.JSON).build();
        res = given().spec(requestSpecification());
        response = res.when().delete("/users")

                .then().spec(responsespec).extract().response();
                 Assert.assertEquals(response.getStatusCode(), 204);



    }






}
